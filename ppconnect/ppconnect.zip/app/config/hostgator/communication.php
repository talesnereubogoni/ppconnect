<?php
return [
    'host'  =>  "localhost",
    'port'  =>  "3306",
    'name'  =>  "ppconn27_ppconnect",
    'user'  =>  "ppconn27_userppc",
    'pass'  =>  "ytXn^bj,G]dx",
    'type'  =>  "mysql",
    'prep'  =>  "1"
];

