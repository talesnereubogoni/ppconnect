<?php
return [
    'host'  =>  "localhost",
    'port'  =>  "3306",
    'name'  =>  "ppconn27_ppconnectpolo",
    'user'  =>  "ppconn27_userpolo",
    'pass'  =>  "#s5Wy&?jdwBY",
    'type'  =>  "mysql",
    'prep'  =>  "1"
];
