<?php
/**
 * BaixarProvasForm Form
 * @author  <your name here>
 */
class BaixarProvasForm extends TPage
{
    protected $form; // form
    protected $id_polo; // id do polo atual
    protected $skey = "Qe2lf0xaVNoR2x8as2KIDMIPhpRTmU7C"; // you can change it
    protected $ciphering = "AES-128-CTR";
    protected $encryption_iv = '5295158302024700';
    
    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();
                
        TTransaction::open('ppconnectpolo');
        $repositorio = new TRepository('Polos');
        $criterio = new TCriteria;
        $criterio->add(new TFilter ('id', '>', 0));                
        $polos = $repositorio->load($criterio);
        $this->id_polo= $polos[0]->id; // carrega o polo atual
        TTransaction::close();
        
        // creates the form
        $this->form = new BootstrapFormBuilder('form_Provas');
        $this->form->setFormTitle('Download de Provas');
        
        $c_download=new TEntry('c_donwload');
        $c_download->setValue(1);
        $c_download->setMask('99');
        
        // create the form fields
        $id = new TEntry('id');
        $nome = new TEntry('nome');
        $disciplinas_id = new TDBCombo('disciplinas_id', 'ppconnectpolo', 'Disciplinas', 'id', 'nome');
        $turmas_id = new TDBCombo('turmas_id', 'ppconnectpolo', 'Turmas', 'id', '{cursos->nome} - {nome}');
        $data_prova = new TDate('data_prova');
        $ativo = new THidden('ativo');        
        $qtd_download = new TEntry('qtd_download');
        $qtd_enviadas_alunos = new TEntry('qtd_enviadas_alunos');
        $qtd_recebidas_alunos = new TEntry('qtd_recebidas_alunos');
        $qtd_upload = new TEntry('qtd_upload');        
        
        $qtd_download->setMask('999');
        $qtd_enviadas_alunos->setMask('999');
        $qtd_recebidas_alunos->setMask('999');
        $qtd_upload->setMask('999');
        $data_prova->setMask('dd/mm/yyyy');
        
        $nome->setEditable(false);
        $disciplinas_id->setEditable(false);
        $turmas_id->setEditable(false);
        $data_prova->setEditable(false);
        $qtd_download->setEditable(false);
        $qtd_enviadas_alunos->setEditable(false);
        $qtd_recebidas_alunos->setEditable(false);
        $qtd_upload->setEditable(false);
        
        // add the fields
        $this->form->addFields( [ new TLabel('Id') ], [ $id ] );
        $this->form->addFields( [ new TLabel('Nome') ], [ $nome ] );
        $this->form->addFields( [ new TLabel('Disciplinas Id') ], [ $disciplinas_id ] );
        $this->form->addFields( [ new TLabel('Turmas Id') ], [ $turmas_id ] );
        $this->form->addFields( [ new TLabel('Data Prova') ], [ $data_prova ] );
        $this->form->addFields( [ new THidden('Ativo') ], [ $ativo ] );
        $this->form->addFields( [ new TLabel('Provas no Sistema') ], [ $qtd_download ], [ new TLabel('Provas Devolvidas') ], [ $qtd_upload ] );
        $this->form->addFields( [ new TLabel('Enviadas para Alunos') ], [ $qtd_enviadas_alunos ], [ new TLabel('Recebidas dos Alunos') ], [ $qtd_recebidas_alunos ] );
        $this->form->addFields( [ new TLabel('Quantidade de Provas para Download') ], [ $c_download ] );

        // set sizes
        $id->setSize('100%');
        $nome->setSize('100%');
        $disciplinas_id->setSize('100%');
        $turmas_id->setSize('100%');
        $data_prova->setSize('100%');
        //$ativo->setSize('100%');
        $qtd_download->setSize('100%');
        $qtd_enviadas_alunos->setSize('100%');
        $qtd_recebidas_alunos->setSize('100%');
        $qtd_upload->setSize('100%');
        $c_download->setSize('10%');
        
        if (!empty($id))
        {
            $id->setEditable(FALSE);
        }
        
        /** samples
         $fieldX->addValidation( 'Field X', new TRequiredValidator ); // add validation
         $fieldX->setSize( '100%' ); // set size
         **/
         
        // create the form actions
        $btn = $this->form->addAction('Fazer o Donnload das Provas', new TAction([$this, 'onSave']), 'fa:save');
        $btn->class = 'btn btn-sm btn-primary';
//        $this->form->addActionLink(_t('New'),  new TAction([$this, 'onEdit']), 'fa:eraser red');
        
        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);
        
        parent::add($container);
    }
    
    private function baixarQuestaoDaProvaGerada($param){
        $location = 'http://localhost/ppconnect/rest.php';
        $parameters = array();
        $parameters['class'] = 'QuestoesDasProvasGeradasService';
        $parameters['method'] = 'loadAll';
        $parameters['filters'] = [['provas_geradas_id', '=', $param->id]];
        $parameters['codigo'] = TSession::getValue('conf_codigo'); 
        $parameters['palavra_passe'] = TSession::getValue('conf_palavra_passe');
        $url = $location . '?' . http_build_query($parameters);
        $obj = json_decode( file_get_contents($url)) ;
//        var_dump($obj);
        try{
            if($obj && $obj->status=='success'){
                // baixar os dados da prova
                TTransaction::open('ppconnectpolo');                
                foreach($obj->data as $ob){
                   // var_dump($ob);               
                    $dados = new QuestoesDasProvasGeradas; 
                    $dados->id                = $ob->id;
                    $dados->questoes_id       = $ob->questoes_id; 
                    $dados->provas_geradas_id = $ob->provas_geradas_id;
                    $dados->numero_da_questao = $ob->numero_da_questao;
                    $dados->a_alternativas_id = $ob->a_alternativas_id;
                    $dados->b_alternativas_id = $ob->b_alternativas_id;
                    $dados->c_alternativas_id = $ob->c_alternativas_id;
                    $dados->d_alternativas_id = $ob->d_alternativas_id;
                    $dados->e_alternativas_id = $ob->e_alternativas_id;
                    $dados->store();
                }
                TTransaction::close();
                
                // baixar as questões usadas na prova
                foreach($obj->data as $ob){
                    $this->baixarQuestao($ob->questoes_id); // passa a id da questão
                    if(! empty( $ob->a_alternativas_id)){
                        $this->baixarAlternativa($ob->a_alternativas_id);
                    } 
                    if(! empty( $ob->b_alternativas_id)){
                        $this->baixarAlternativa($ob->b_alternativas_id);
                    }
                    if(! empty( $ob->c_alternativas_id)){
                        $this->baixarAlternativa($ob->c_alternativas_id);
                    }
                    if(! empty( $ob->d_alternativas_id)){
                        $this->baixarAlternativa($ob->d_alternativas_id);
                    }
                    if(! empty( $ob->e_alternativas_id)){
                        $this->baixarAlternativa($ob->e_alternativas_id);
                    }
                }
         
            }
            return true;
        } catch (Exception $e){
            return false;
        }
        return true;
    }
    
    
    private function baixarMidia($param){
    //echo $param;
        $location = 'http://localhost/ppconnect/rest.php';
        $parameters = array();
        $parameters['class'] = 'QuestoesService';
        $parameters['method'] = 'loadMidia';
        $parameters['codigo'] = TSession::getValue('conf_codigo'); 
        $parameters['palavra_passe'] = TSession::getValue('conf_palavra_passe');
        $parameters['url_midia'] = $param;
        $url = $location . '?' . http_build_query($parameters);
        $obj = json_decode( file_get_contents($url)) ;
//        var_dump ($obj->data);
        return stripslashes($obj->data);    
    }
    
    private function baixarVideo($param){
        //var_dump($param);
        //var_dump($this);
        $location = 'http://localhost/ppconnect/rest.php';
        $parameters = array();
        $parameters['class'] = 'QuestoesService';
        $parameters['method'] = 'loadMidia';
        $parameters['codigo'] = TSession::getValue('conf_codigo'); 
        $parameters['palavra_passe'] = TSession::getValue('conf_palavra_passe');
        $parameters['url_midia'] = $param;
        $url = $location . '?' . http_build_query($parameters);
        $obj = json_decode( file_get_contents($url)) ;        
        $obj = stripslashes($obj->data);
        
        $start = strpos($obj, 'base64, ') + 8; 
        $end = strpos($obj, ']')-1;
        $bin = base64_decode(substr($obj,$start, $end-$start));
        $size = getImageSizeFromString($bin);
        $parts = explode("/",$param);
        //print_r($parts);
        $img_file = './files/video/questao/'.$parts[4].$parts[5];
        file_put_contents($img_file, $bin);
        return $img_file;    
    }
    
    
    private function baixarQuestao($param){
    // 1. verificar se ainda não foi baixada
        $existe = Questoes::where('id','=',$param)->count();        
    // 2. baixar a questao
        if($existe==0){ // prova ainda não baixada
            $location = 'http://localhost/ppconnect/rest.php';
            $parameters = array();
            $parameters['class'] = 'QuestoesService';
            $parameters['method'] = 'load';
            $parameters['id'] = $param;
            $parameters['codigo'] = TSession::getValue('conf_codigo'); 
            $parameters['palavra_passe'] = TSession::getValue('conf_palavra_passe');
            //$parameters['url_img'] = './files/midia/questoes/60/imagem.jpeg';
            
            $url = $location . '?' . http_build_query($parameters);
            $obj = json_decode( file_get_contents($url)) ;
        // 3. Salvar a questão
            try{
                if($obj && $obj->status=='success'){
                    TTransaction::open('ppconnectpolo');                
                    $dados = new Questoes; 
                    $dados->id                = $obj->data->id;
                    $dados->questoes_tipos_id = $obj->data->questoes_tipos_id; 
                    $dados->texto             = $this->encode($obj->data->texto);
                                        
                    if(!empty($obj->data->imagem)){
                        $dados->imagem = $this->baixarMidia('./'.$obj->data->imagem);
                    }
                    if(!empty($obj->data->audio)){
                        $dados->audio = $this->baixarMidia('./'.$obj->data->audio);
                    }
                    if(!empty($obj->data->video)){
                        $dados->video = $this->baixarVideo('./'.$obj->data->video);
                    }
                    
                    $dados->store();
                    TTransaction::close();                    
                }
            } catch (Exception $e){
                return false;
            }
        }              
    // 3. baixar as midias da questão
    }
    
    private function baixarAlternativa($param){
    // 1. verificar se ainda não foi baixada
        $existe = QuestoesAlternativas::where('id','=',$param)->count();        
    // 2. baixar a alternativa
        if($existe==0){ // prova ainda não baixada
            $location = 'http://localhost/ppconnect/rest.php';
            $parameters = array();
            $parameters['class'] = 'QuestoesAlternativasService';
            $parameters['method'] = 'load';
            $parameters['id'] = $param;
            $parameters['codigo'] = TSession::getValue('conf_codigo'); 
            $parameters['palavra_passe'] = TSession::getValue('conf_palavra_passe');
            $url = $location . '?' . http_build_query($parameters);
            $obj = json_decode( file_get_contents($url)) ;
//            var_dump($obj);
        // 3. Salvar a questão
            try{
                if($obj && $obj->status=='success'){
                    
                    TTransaction::open('ppconnectpolo');                
                    $dados = new QuestoesAlternativas; 
                    $dados->id                = $obj->data->id;
                    $dados->questoes_id       = $obj->data->questoes_id; 
                    $dados->texto             = $this->encode($obj->data->texto);
                    
                    if(!empty($obj->data->imagem)){
                        $dados->imagem = $this->baixarMidia('./'.$obj->data->imagem);
                    }
                    if(!empty($obj->data->audio)){
                        $dados->audio = $this->baixarMidia('./'.$obj->data->audio);
                    }
                    if(!empty($obj->data->video)){
                        $dados->video = $this->baixarMidia('./'.$obj->data->video);
                    }
                    $dados->store();
                    TTransaction::close();
                }
            } catch (Exception $e){
                return false;
            }
        }           
    // 3. baixar as midias da questão
    }
        
    private function confirmaRecebimento($param){
        $location = 'http://localhost/ppconnect/rest.php';
        $parameters = array();
        $parameters['class'] = 'ProvasGeradasService';
        $parameters['method'] = 'store';
        $parameters['codigo'] = TSession::getValue('conf_codigo'); 
        $parameters['palavra_passe'] = TSession::getValue('conf_palavra_passe');
        $parameters['data'] = [ 'id'              => $param->id,
                                'polos_id'        => $param->polos_id,
                                'data_enviada'    => $param->data_enviada,
                                'usada'           => 'S'
                              ];
       // var_dump($this);
        $url = $location . '?' . http_build_query($parameters);
        $obj = json_decode( file_get_contents($url)) ;
        if($obj->status == 'success')
            return true;
        return false;
    }

    //passa o numero da prova
    private function baixarProva($param){
        $location = 'http://localhost/ppconnect/rest.php';
        $parameters = array();
        $parameters['class'] = 'ProvasGeradasService';
        $parameters['method'] = 'baixarProva';
        $parameters['provas_id'] = $param;
        $parameters['polos_id'] = $this->id_polo;
        $parameters['codigo'] = TSession::getValue('conf_codigo'); 
        $parameters['palavra_passe'] = TSession::getValue('conf_palavra_passe');
       // var_dump($this);
        $url = $location . '?' . http_build_query($parameters);
        $obj = json_decode( file_get_contents($url)) ;
//        var_dump($obj);
        if($obj && $obj->status=='success'){
            try{      
                $ob = $obj->data[0];
                TTransaction::open('ppconnectpolo');
                //$this->setActiveRecord('ProvasGeradas'); 
                $dados = new ProvasGeradas; 
                $dados->id              = $ob->id;
                $dados->provas_id       = $ob->provas_id; 
                $dados->polos_id        = $this->id_polo;
                $dados->numero_da_prova = $ob->numero_da_prova;
                $dados->data_criada     = $ob->data_criada;
                $dados->data_enviada    = date('Y-m-d H:i:s'); // data adual (recebimento da prova)
                $dados->store();
                TTransaction::close();
                if($this->confirmaRecebimento($dados))
                    if($this->baixarQuestaoDaProvaGerada($dados)){
                          TToast::show('show', 'Prova recebida com sucesso', 'top right', 'far:check-circle' );
//                        new TMessage('ok', "Prova recebida com sucesso");
                        return true;
                    }
    
            } catch (Exception $e){
                new TMessage('error', $e->getMessage());
                return false;
            }         
        }
        return false;        
    }


    /**
     * Save form data
     * @param $param Request
     */
    public function onSave( $param )
    {
        
        try
        {
            TTransaction::open('ppconnectpolo'); // open a transaction
            
            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/
            
            $this->form->validate(); // validate form data
            $data = $this->form->getData(); // get form data as array
            
            $object = new Provas;  // create an empty object
            $object->fromArray( (array) $data); // load the object with data
            
            for($i=0; $i<$data->c_donwload; $i++){
                $this->baixarProva($data->id);
            }
            echo  $object->qtd_download. ' - ';
            $object->qtd_download+=$data->c_donwload;
            echo  $object->qtd_download;
            $object->store(); // save the object                        
            // get the generated id
            $data->id = $object->id;
            
            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction
            
            //$back =  new TAction(array('CalendarioList','onReload'));  
            new TMessage('info', $i.' Provas salvas no computador');//, $back);
            
        }
        catch (Exception $e) // in case of exception
        {
            $back =  new TAction(array('CalendarioList','onReload'));
            new TMessage('error', $e->getMessage(), $back); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }
    
    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(TRUE);
    }
    
    /**
     * Load object to form data
     * @param $param Request
     */
    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open('ppconnectpolo'); // open a transaction
                $object = new Provas($key); // instantiates the Active Record
                $this->form->setData($object); // fill the form
                TTransaction::close(); // close the transaction
            }
            else
            {
                $this->form->clear(TRUE);
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }
    
    public function onCarregaDados ($param){
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open('ppconnectpolo'); // open a transaction
                $object = new Provas($key); // instantiates the Active Record
                $this->form->setData($object); // fill the form
                TTransaction::close(); // close the transaction
            }
            else
            {
                $this->form->clear(TRUE);
            }
        }
        catch (Exception $e) // in case of exception
        {
            TTransaction::open('ppconnectpolo'); // open a transaction
            $object = new Provas;
            $object->id = $param['key'];
            $crit = new TCriteria();
            $crit->add(new TFilter('id','=',$param['key']));
            $repositorio = new TRepository('Calendario');         
            $dados = $repositorio->load($crit);
            
            TTransaction::close();
            foreach($dados as $dado){
                $object->nome = $dado->descricao;
                $object->disciplinas_id = $dado->disciplinas_id;
                $object->turmas_id = $dado->turmas_id;
                $object->data_prova = $dado->data_prova;
                $object->ativo = $dado->ativo;
                $object->qtd_download=0;
                $object->qtd_enviadas_alunos=0;
                $object->qtd_recebidas_alunos=0;
                $object->qtd_upload=0;
                $object->store();
                $this->form->setData($object); // fill the form
            }
        }
    }
    
    public  function encode($value){ 
        if(!$value){return false;}
        $encryption = openssl_encrypt($value, $this->ciphering, $this->skey, 0, $this->encryption_iv); 
        return $encryption; 
    }
    
    public function decode($value){
        if(!$value){return false;}
        $text = openssl_decrypt ($value, $this->ciphering, $this->skey, 0, $this->encryption_iv);        
        return trim($text);
    }
}
