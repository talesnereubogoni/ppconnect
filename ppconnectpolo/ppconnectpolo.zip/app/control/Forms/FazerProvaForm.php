<?php
/**
 * FazerProvaForm Registration
 * @author  <your name here>
 */
class FazerProvaForm extends TPage
{
    protected $form; // form
    protected $id_prova;
    protected $questao_atual = 0;
    protected $questao_total = 0;
    protected $skey = "Qe2lf0xaVNoR2x8as2KIDMIPhpRTmU7C"; // you can change it
    protected $ciphering = "AES-128-CTR";
    protected $encryption_iv = '5295158302024700';
    protected $resposta_texto;
    protected $questaodaprova;
    protected $questao;
    protected $resposta_alternativa;
    
    use Adianti\Base\AdiantiStandardFormTrait; // Standard form methods
    
    /**
     * Class constructor
     * Creates the page and the registration form
     * Passa a prova que será feita pelo aluno
     */
    function __construct($param)
    {
        parent::__construct();
        
        $this->resposta_texto= new TText('resposta_texto');
        $this->setDatabase('ppconnectpolo');              // defines the database
        $this->setActiveRecord('ProvasGeradas');     // defines the active record        
    
        if(TSession::getValue('qa')!=null)
            $this->questao_atual=TSession::getValue('qa');
        else
            new TMessage('error', $e->getMessage()); // shows the exception error message
            
        if(TSession::getValue('qt')!=null)
             $this->questao_total = TSession::getValue('qt');
        else
            new TMessage('error', $e->getMessage()); // shows the exception error message
                
        if(TSession::getValue('form_id_prova')==null){            
            TSession::setValue('form_id_prova',$param['id_prova']);
            if(isset($param['id_prova']))
                $id_prova= $param['id_prova'];
            else 
                new TMessage('error', $e->getMessage()); // shows the exception error message            
        }
        else 
            $id_prova = TSession::getValue('form_id_prova');

        $this->resposta_alternativa = new TRadioGroup('rep_alternativa');
        
        
        // creates the form
        $this->form = new BootstrapFormBuilder('form_ProvasGeradas');
        $this->form->setFormTitle(TSession::getValue('nome_aluno').
                                  ' sua Prova '. TSession::getValue('nome_aluno') .' de '.TSession::getValue('disciplina_aluno'));
              
        $button = new TButton('hide');
        $button->class = 'btn btn-default btn-sm active';
        $button->setLabel('Anterior');
        $button1 = new TButton('show');
        $button1->class = 'btn btn-default btn-sm active';
        $button1->setLabel('Próximo');        
        
        // create the form fields
        $id = new THidden('id');
        $lbl_questao = new TLabel('Questão '. (int)($this->questao_atual) .' / '.$this->questao_total);


        // add the fields
        $this->form->addFields( [ new THidden('Id') ], [ $id ] );
        $this->form->addFields( [ $lbl_questao ]);

        // set sizes
        $id->setSize('100%');
        $lbl_questao->setSize('100%');
        
         
        // create the form actions
        $btn_ant = $this->form->addAction('Questão Anterior', new TAction([$this, 'onAnterior']), 'fa:save');
        $btn_ant->class = 'btn btn-sm btn-success btn-lg ';
        $btn_prox = $this->form->addAction('Próxima Questão', new TAction([$this, 'onProximo']), 'fa:save');
        $btn_prox->class = 'btn btn-sm btn-success btn-lg ';
        $btn_confirma = $this->form->addAction('Confirmar Resposta', new TAction([$this, 'onResposta']), 'fa:save');
        $btn_confirma->class = 'btn btn-sm btn-warning btn-lg ';        
        $btn_fim = $this->form->addAction('FINALIZAR PROVA', new TAction([$this, 'onFinaliza']), 'fa:save');
        $btn_fim->class = 'btn btn-sm btn-danger btn-lg ';

        
               
        // CARREGA A QUESTÃO           
        TTransaction::open('ppconnectpolo');
        $this->questaodaprova = QuestoesDasProvasGeradas::where('provas_geradas_id','=',TSession::getValue('form_id_prova'))->
                          where('numero_da_questao','=',TSession::getValue('qa'))->load()[0];
        $this->questao = Questoes::where('id','=',$this->questaodaprova->questoes_id)->load()[0];
        TTransaction::close();

               
        // ENUNCIADO DA QUESTÃO COM TEXTO 
        if(!empty($this->questao->texto)){
            $lbl_enunciado = new TLabel($this->decode($this->questao->texto));
            $this->form->addFields( [ $lbl_enunciado ] );            
        }
        
        // IMAGEM DO ENUNCIADO
        $img_questao= new TImage('');
        if(!empty($this->questao->imagem)){
            $start = strpos($this->questao->imagem, '[') + 1; 
            $end = strpos($this->questao->imagem, ']')-1;      

            $divFoto = new TElement('div');
            $divFoto->id = 'divFoto';
            $divFoto->style = "width:100px;height:100px;text-align: center";
            $imgFoto = new TElement('img');
            $imgFoto->src = 'data:'.substr($this->questao->imagem, $start, $end-$start);
            $imgFoto->style = "width:250%;height:250px;";
            $divFoto->add($imgFoto);
            $frame1 = new TFrame(250,250);
            $frame1->add($divFoto);
        
                    
                
            $this->form->addFields( [ $frame1 ]);
            
        }
        $bt_video = new TButton('video');
        $bt_video->class = 'btn btn-default btn-sm active';
        $bt_video->setLabel('Vídeo');
        $bt_audio = new TButton('audio');
        $bt_audio->class = 'btn btn-default btn-sm active';
        $bt_audio->setLabel('Audio');
      
        if(!empty($this->questao->audio) && !empty($this->questao->video)){
            $this->form->addFields( [ $bt_audio ], [$bt_video]);
        } else if(!empty($this->questao->audio)){
            $this->form->addFields( [ $bt_audio ]);
        } else if(!empty($this->questao->video)){
            $this->form->addFields( [ $bt_video ]);
        }
              
/*            
        $video_questao= ' ';
        if(!empty($questao->video)){
          
            $tagVideo = '<video  width="640" height="480" controls ';
            $tagSource = ' src= "/ppconnectpolo/'.$questao->video;
            $tagVideo.= $tagSource;
            $tagVideo.='" type="video/mp4 />';
            //$video_questao = $tagVideo;
//            $frame_questoes->add($this->tagVideo);
//            var_dump($this->tagVideo);
//            $row = $table->addRow();            
//            $row->addcell($this->tagVideo);
            //$form_questao->addFields( [ new TLabel('video')], ['tem video']);
        }
  */      
        
        //Respostas
        
        TTransaction::open('ppconnectpolo');
        //$this->questaodaprova = QuestoesDasProvasGeradas::where('provas_geradas_id','=',TSession::getValue('form_id_prova'))->
        //                  where('numero_da_questao','=',TSession::getValue('qa'))->load()[0];
        //$this->questao = Questoes::where('id','=',$this->questaodaprova->questoes_id)->load()[0];
        
        
        // Questões de múltipla escolha 
        if($this->questao->questoes_tipos_id==2) { 
            $items_alternativas = [];
            if(!empty($this->questaodaprova->a_alternativas_id)){
                $alt_a = QuestoesAlternativas::where('id','=',$this->questaodaprova->a_alternativas_id)->load();
                if($alt_a!=null){
                    $items_alternativas['A'] = $this->decode($alt_a[0]->texto);
                }  
            }
            if(!empty($this->questaodaprova->b_alternativas_id)){
                $alt_b = QuestoesAlternativas::where('id','=',$this->questaodaprova->b_alternativas_id)->load();
                if($alt_b!=null){
                    $items_alternativas['B'] = $this->decode($alt_b[0]->texto);
                }  
            }
            if(!empty($this->questaodaprova->c_alternativas_id)){
                $alt_c = QuestoesAlternativas::where('id','=',$this->questaodaprova->c_alternativas_id)->load();
                if($alt_c!=null){
                    $items_alternativas['C'] = $this->decode($alt_c[0]->texto);
                }  
            }
            if(!empty($this->questaodaprova->d_alternativas_id)){
                $alt_d = QuestoesAlternativas::where('id','=',$this->questaodaprova->d_alternativas_id)->load();
                if($alt_d!=null){
                    $items_alternativas['D'] = $this->decode($alt_d[0]->texto);
                }  
            }
            if(!empty($this->questaodaprova->e_alternativas_id)){
                $alt_e = QuestoesAlternativas::where('id','=',$this->questaodaprova->e_alternativas_id)->load();
                if($alt_e!=null){
                    $items_alternativas['E'] = $this->decode($alt_e[0]->texto);
                }  
            }
            
            $this->resposta_alternativa->addItems($items_alternativas);
            $this->form->addFields( [ $this->resposta_alternativa ]);
        }
        
        
        // Questões abertas 
        if($this->questao->questoes_tipos_id==1 ) { // subjetiva
            $this->resposta_texto->setSize('100%');
            $frm = new TFrame("95%", 150);
            $frm->add( $this->resposta_texto);                       
            $this->form->addFields( [ $frm ] );
        }
        
        $this->resposta_texto->setValue($this->questaodaprova->resposta_texto);
        if($this->questao->questoes_tipos_id==2 && isset($this->questaodaprova->resposta_letra))
             $this->resposta_alternativa->setValue($this->questaodaprova->resposta_letra);        
        
        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);
//        $container->add($frame_questoes);
//        $container->add($this->tagVideo);
        
        parent::add($container);
    }
    
    public function onStart($param){
        //$id_prova = $param['id_prova'];        
    }
    
    public function onFinaliza($param){
        TTransaction::open('ppconnectpolo');
        $pf = ProvasFeitas::where('provas_geradas_id','=', TSession::getValue('form_id_prova'))->load();
        $dataAtual = new DateTime();
        $pf[0]->fim= $dataAtual->format('Y-m-d H:i:s'); 
        $pf[0]->store();       
        TTransaction::close();
        $back = new TAction(array('SelecionarProvaForm','onClear'));
        new TMessage('info', "Prova Finalizada", $back);
    }
    
    public function onAnterior($param){
        if($this->questao_atual>1){
           TSession::setValue('qa',$this->questao_atual-1);
           $param['x']='x';
           AdiantiCoreApplication::loadPage('FazerProvaForm', 'onStart', $param);
        }        
    }    

    public function onProximo($param){
        if($this->questao_atual<$this->questao_total){
            TSession::setValue('qa',$this->questao_atual+1);
            $param['x']='x';
            AdiantiCoreApplication::loadPage('FazerProvaForm', 'onStart', $param);
        }
    }
        
    public  function encode($value){ 
        if(!$value){return false;}
        $encryption = openssl_encrypt($value, $this->ciphering, $this->skey, 0, $this->encryption_iv); 
        return $encryption; 
    }
    
    public function decode($value){
        if(!$value){return false;}
        $text = openssl_decrypt ($value, $this->ciphering, $this->skey, 0, $this->encryption_iv);        
        return trim($text);
    }
    
    public function onResposta($param){
            $data = $this->form->getData(); // get form data as array
            try{
                var_dump($this->resposta_texto->getPostData());
            } catch (Exception $e) {}
            TTransaction::open('ppconnectpolo');
            $this->questaodaprova->resposta_texto = $this->resposta_texto->getPostData();
            if($this->questao->questoes_tipos_id==2 && isset($data->rep_alternativa))
                $this->questaodaprova->resposta_letra =  $data->rep_alternativa;
            $this->questaodaprova->store(); 
            TTransaction::close();
            new TMessage('info', 'Resposta gravada!');
            AdiantiCoreApplication::loadPage('FazerProvaForm', 'onStart', $param);
    }
    
}
