<?php
/**
 * AtualizacoesList Listing
 * @author  <your name here>
 */
class AtualizacoesList extends TPage
{
    protected $form;     // registration form
    protected $datagrid; // listing
    protected $pageNavigation;
    protected $formgrid;
    protected $deleteButton;
    
    use Adianti\base\AdiantiStandardListTrait;
    
    /**
     * Page constructor
     */
    public function __construct()
    {
        parent::__construct();
        
        $this->setDatabase('ppconnectpolo');            // defines the database
        $this->setActiveRecord('Atualizacoes');   // defines the active record
        $this->setDefaultOrder('atualizacoes_id', 'asc');         // defines the default order
        $this->setLimit(10);
        // creates a Datagrid
        $this->datagrid = new BootstrapDatagridWrapper(new TDataGrid);
        $this->datagrid->style = 'width: 100%';
        $this->datagrid->datatable = 'true';
        // $this->datagrid->enablePopover('Popover', 'Hi <b> {name} </b>');

        // creates the datagrid columns
        $column_nome = new TDataGridColumn('nome', 'Nome', 'left');
        $column_data = new TDataGridColumn('data_atualizacao', 'Última Atualização', 'left');
        $column_data->setTransformer(array($this, 'formatDate'));


        // add the columns to the DataGrid
        $this->datagrid->addColumn($column_nome);
        $this->datagrid->addColumn($column_data);

        $action1 = new TDataGridAction([$this, 'onVerificarAtualizacoes'], ['atualizacoes_id'=>'{atualizacoes_id}']);
        
        $this->datagrid->addAction($action1, 'Atualizar',   'fa:recycle blue');
        
        // create the datagrid model
        $this->datagrid->createModel();
                
        $panel = new TPanelGroup('Atualização de dados', 'white');
        $panel->add($this->datagrid);

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        //$container->add($this->form);
        $container->add($panel);
        
        parent::add($container);
    }
    
    public function formatDate($date, $object)
    {
        if(!empty($date)){
            $dt = new DateTime($date);
            return $dt->format('d/m/Y');
        }
        return ' ';
    }
    
    private function atualizaData($param){
         try{
             TTransaction::open('ppconnectpolo');
             $this->setActiveRecord('Atualizacoes');
             $atual = new Atualizacoes($param);
             $atual->data_atualizacao = date('Y-m-d H:i:s');
             $atual->store();
             TTransaction::close();
             return true;
           } catch (Exception $e){
              return false;
          }
          
    }
    
    public function onVerificarAtualizacoes($param=null)
    {
        switch($param['key']){
            case 1 : if( $this->atualizaCursosTurmas())
                     {
                         $this->atualizaData($param['atualizacoes_id']);
                     }        
                     break;
            case 2 : if( $this->atualizaDisciplinasDoCurso())
                     {
                         $this->atualizaData($param['atualizacoes_id']);
                     }        
                     break;
            case 3 : if( $this->atualizaTutores())
                     {
                         $this->atualizaData($param['atualizacoes_id']);
                     }        
                     break;
            case 4 : if( $this->atualizaTurmasDoPolo())
                     {
                         $this->atualizaData($param['atualizacoes_id']);
                     }        
                     break;
        }
        $this->onReload();        
    }
    
    private function atualizaGrupos(){
        //$location = 'https://localhost/ppconnect/rest.php';
        $location = 'https://dash.ppconnect.com.br/rest.php';
        $parameters = array();
        $parameters['class'] = 'SystemGroupService';
        $parameters['method'] = 'loadAll';
        $parameters['filters'] = [['id', '>', '0']];
        $url = $location . '?' . http_build_query($parameters);
        $obj= json_decode( file_get_contents($url)) ;            
        TTransaction::open('ppconnectpolo');
        if($obj->status=='success'){
            try{
                $dados = new SystemGroup;                       
                foreach($obj->data as $ob){
                    $dados->id     = $ob->id;
                    $dados->name   = $ob->name; 
                    $dados->store();
                }
                    
            } catch (Exception $e){
                new TMessage('error', $e->getMessage());
                return false;
            }
         }
         TTransaction::close();                                                        
         return true;    
    }
    
    //passa por parâmetro a id do usuário e cadastra nos grupos
    private function atualizaUsuariosDoGrupo($param){
        //$location = 'http://localhost/ppconnect/rest.php';
        $location = 'https://dash.ppconnect.com.br/rest.php';
        $parameters = array();
        $parameters['class'] = 'SystemUserGroupService';
        $parameters['method'] = 'loadAll';
        $parameters['filters'] = [['system_user_id', '=', $param]];
        $url = $location . '?' . http_build_query($parameters);
        $obj= json_decode( file_get_contents($url)) ;            
        TTransaction::open('ppconnectpolo');
        if($obj->status=='success'){
            try{
                $dados = new SystemUserGroup;                       
                foreach($obj->data as $ob){
                    $dados->id               = $ob->id;
                    $dados->system_user_id   = $ob->system_user_id; 
                    $dados->system_group_id  = $ob->system_group_id;
                    $dados->store();
                }
                    
            } catch (Exception $e){
                new TMessage('error', $e->getMessage());
                return false;
            }
         }
         TTransaction::close();                                                        
        return true;    
    }
    
    private function atualizaTutores(){
        $this->atualizaGrupos();
     
        //$location = 'http://localhost/ppconnect/rest.php';
        $location = 'httsp://dash.ppconnect.com.br/rest.php';
        $parameters = array();
        $parameters['class'] = 'SystemUserService';
        $parameters['method'] = 'loadTutores';
        $parameters['codigo'] = TSession::getValue('conf_codigo'); 
        $parameters['palavra_passe'] = TSession::getValue('conf_palavra_passe'); 
        $url = $location . '?' . http_build_query($parameters);
        $obj= json_decode( file_get_contents($url)) ;
        try{
            $this->setActiveRecord('SystemUser'); 
            TTransaction::open('ppconnectpolo');
            $user = new SystemUser; 
            foreach($obj->data as $ob){                            
                $user->id           = $ob->id;
                $user->name         = $ob->name; 
                $user->cpf          = $ob->cpf;
                $user->login        = $ob->login;
                $user->password     = $ob->password;
                $user->email        = $ob->email;
                $user->active       = $ob->active;
                $user->polos_id     = $ob->polos_id;
                
                $this->atualizaUsuariosDoGrupo($user->id);
                $this->setActiveRecord('SystemUser'); 
                TTransaction::open('ppconnectpolo');
                $user->store();
                TTransaction::close();
            }
            
            $this->setActiveRecord('Atualizacoes');
            new TMessage('info', 'Tutores atualizados!');                              

        } catch (Exception $e){
            new TMessage('error', $e->getMessage());
            return false;
        }
         
        return true;
    }
    
     private function atualizaCursosTurmas(){
        //$location = 'http://localhost/ppconnect/rest.php';
        $location = 'https://dash.ppconnect.com.br/rest.php';
        $parameters = array();
        $parameters['class'] = 'TurmasDoPoloService';
        $parameters['method'] = 'loadTurmasDoPolo';
        $parameters['codigo'] = TSession::getValue('conf_codigo'); 
        $parameters['palavra_passe'] = TSession::getValue('conf_palavra_passe'); 
        $url = $location . '?' . http_build_query($parameters);
        $obj= json_decode( file_get_contents($url)) ;
        try{
            $this->setActiveRecord('TurmasDoPolo'); 
            $dados = new TurmasDoPolo; 
            foreach($obj->data as $ob){                            
                $dados->id           = $ob->id;
                $dados->turmas_id    = $ob->turmas_id; 
                $dados->polos_id     = $ob->polos_id;
                
                // carregar carregar o polo
                $this->atualizaPolos($dados->polos_id);
                
                // carregar a turma
                $this->atualizaTurmas($dados->turmas_id);
                
                try{
                    TTransaction::open('ppconnectpolo');
                    $dados->store();
                    TTransaction::close();
                }  catch (Exception $e){
                    new TMessage('error', $e->getMessage());
                   }
            }
            
            $this->setActiveRecord('Atualizacoes');
            new TMessage('info', 'Turmas atualizadas!');                              

        } catch (Exception $e){
            new TMessage('error', $e->getMessage());
            return false;
        }
         
        return true;    
    }
    
    private function atualizaPolos($param){
        //$location = 'http://localhost/ppconnect/rest.php';
        $location = 'https://dash.ppconnect.com.br/rest.php';
        $parameters = array();
        $parameters['class'] = 'PolosService';
        $parameters['method'] = 'load';
        $parameters['id'] = $param; 
        $url = $location . '?' . http_build_query($parameters);
        $ob = json_decode( file_get_contents($url)) ;
        if($ob){
            try{
                $this->setActiveRecord('Polos'); 
                TTransaction::open('ppconnectpolo');
                $dados = new Polos; 
                $dados->id           = $ob->data->id;
                $dados->nome         = $ob->data->nome; 
                $dados->bairro       = $ob->data->bairro;
                $dados->rua          = $ob->data->rua;
                $dados->numero       = $ob->data->numero;
                $dados->telefone     = $ob->data->telefone;
                $dados->cep          = $ob->data->cep;   
                $dados->email        = $ob->data->email;
                $dados->whatsapp     = $ob->data->whatsapp;
                $dados->coordenador  = $ob->data->coordenador;
                $dados->store();
                TTransaction::close();
                return true;
    
            } catch (Exception $e){
                new TMessage('error', $e->getMessage());
                return false;
            }         
        }
        return false;    
    }
    
    
    
    /**
     * Recupera as turmas do polo usando o código de acesso cadastrada na identificação
     * chama o método para atualizar os dados das turmas    
     */
    private function atualizaTurmasDoPolo(){
        $parameters = array();
        $parameters['class'] = 'TurmasDoPoloService';
        $parameters['method'] = 'loadTurmasDoPolo';
        $parameters['codigo'] = TSession::getValue('conf_codigo');
        $url = TSession::getValue('conf_path_bd') . '/rest.php?' . http_build_query($parameters);
        echo $url;
        $list_obj= json_decode( file_get_contents($url)) ;
        var_dump($list_obj);
        if($list_obj && $list_obj->status=='success'){
            try{
                $erro=0;
                // carrega os dados da turma
                foreach($list_obj->data as $obj){
                    if($this->atualizaTurma($obj->turmas_id)){
                        $this->setActiveRecord('TurmasDoPolo'); 
                        TTransaction::open('ppconnectpolo');
                        $dados = new TurmasDoPolo; 
                        $dados->id           = $obj->id;
                        $dados->turmas_id    = $obj->turmas_id;
                        $dados->polos_id     = $obj->polos_id;                
                        $dados->store();            
                        TTransaction::close();                    
                    } else
                        $erro++;
                }
                if($erro>0){
                    new TMessage('error', 'Erro na atualização das Turmas do Polo');
                    return false;
                }
                return true;    
            } catch (Exception $e){
                new TMessage('error', 'Erro na atualização das Turmas do Polo');
                return false;
            }
        } else
            new TMessage('error', 'Erro na comunicação de dados com o servidor central.');                 
        return false;    
    }
    
        
     /**
     * Recupera os dados de uma turma "nome" e "curso_id"
     * recebe como parâmetro o id da turma    
     * é chamado pelo método que atualiza as turmas do polo
     * chama o método que atualiza os cursos
     * o parâmetro é a id da turma
     */
     private function atualizaTurma($param){
        $parameters = array();
        $parameters['class'] = 'TurmasService';
        $parameters['method'] = 'load';
        $parameters['id'] = $param; 
        $url = TSession::getValue('conf_path_bd') . '/rest.php?' . http_build_query($parameters);
        $obj= json_decode( file_get_contents($url)) ;
        var_dump($obj);
        if($obj && $obj->status=='success'){
            try{
                // atualiza os cursos
                // verifica se atualizou o curso
                if( $this->atualizaCurso($obj->data->cursos_id)){                
                    $this->setActiveRecord('Turmas'); 
                    TTransaction::open('ppconnectpolo');
                    $dados = new Turmas; 
                    $dados->id           = $obj->data->id;
                    $dados->nome         = $obj->data->nome;
                    $dados->cursos_id    = $obj->data->cursos_id;
                    $dados->store();            
                    TTransaction::close();
                    return true;
                }
            } catch (Exception $e){
                new TMessage('error', 'Erro na atualização das Turmas');
                return false;
            }
        } else
            new TMessage('error', 'Erro na comunicação de dados com o servidor central.');        
        return false;    
    }
    
     /**
     * Recupera os dados de um curso "id" e "nome"
     * recebe como parâmetro o id do curso    
     * é chamado pelo método que atualiza a turma
     * o parâmetro é a id do curso 
     */
    private function atualizaCurso($param){
        $parameters = array();
        $parameters['class'] = 'CursosService';
        $parameters['method'] = 'load';
        $parameters['id'] = $param; 
        $url = TSession::getValue('conf_path_bd') . '/rest.php?' . http_build_query($parameters);
        $obj= json_decode( file_get_contents($url)) ;
        var_dump($obj);
        if($obj && $obj->status=='success'){
            try{
                $this->setActiveRecord('Cursos'); 
                TTransaction::open('ppconnectpolo');
                $dados = new Cursos; 
                $dados->id           = $obj->data->id;
                $dados->nome         = $obj->data->nome; 
                $dados->store();
                TTransaction::close();
                return true;
            } catch (Exception $e){
                new TMessage('error', 'Erro na atualização dos Cursos');
                return false;
            }      
        } else
            new TMessage('error', 'Erro na comunicação de dados com o servidor central.');
        return false;    
    }
    
    //atualiza as disciplinas e as disciplinas do curso que estão cadastradas no polo
    private function atualizaDisciplinasDoCurso(){
        TTransaction::open('ppconnectpolo');
        $repositorio = new TRepository('Cursos');
        $criterio = new TCriteria;
        $criterio->add(new TFilter ('id', '>', 0));                
        $cursos = $repositorio->load($criterio);
        //var_dump($cursos);
        TTransaction::close();
        foreach($cursos as $curso){        
            //$location = 'http://localhost/ppconnect/rest.php';
            $location = 'https://dash.ppconnect.com.br/rest.php';
            $parameters = array();
            $parameters['class'] = 'DisciplinasDoCursoService';
            $parameters['method'] = 'loadAll';
            $parameters['filters'] = [['curso_id', '=', $curso->id]];
            $url = $location . '?' . http_build_query($parameters);
            $obj= json_decode( file_get_contents($url)) ;            
          //  var_dump($obj);
            TTransaction::open('ppconnectpolo');
                        
            foreach($obj->data as $ob){
//                var_dump($ob);
                //salva as disciplinas
                $this->setActiveRecord('Disciplinas');             
                //$location = 'http://localhost/ppconnect/rest.php';
                $location = 'https://dash.ppconnect.com.br/rest.php';
                $parameters = array();
                $parameters['class'] = 'DisciplinasService';
                $parameters['method'] = 'load';
                $parameters['id']=$ob->disciplinas_id;
                $url = $location . '?' . http_build_query($parameters);
                $obj_disciplina= json_decode( file_get_contents($url)) ;
            //    var_dump($obj_disciplina);
                if($obj_disciplina->status=='success'){
                    try{
                        $dados = new Disciplinas; 
                        $dados->id           = $obj_disciplina->data->id;
                        $dados->nome          = $obj_disciplina->data->nome; 
                        $dados->sigla         = $obj_disciplina->data->sigla;
                        $dados->store();
                        
                    } catch (Exception $e){
                        new TMessage('error', $e->getMessage());
                    }
                }
                //salva as disciplinas do curso
                $this->setActiveRecord('DisciplinasDoCurso');
                $dados_dc = new DisciplinasDoCurso;
                $dados_dc->id        = $ob->id;
                $dados_dc->disciplinas_id = $ob->disciplinas_id;
                $dados_dc->curso_id    = $ob->curso_id;
                $dados_dc->store();                     
             }
             TTransaction::close();                                                        
        }
        $this->setActiveRecord('Atualizacoes');
        new TMessage('info', 'Disciplinas atualizadas!');                              
        return true;    
    }
    
    
    
}
